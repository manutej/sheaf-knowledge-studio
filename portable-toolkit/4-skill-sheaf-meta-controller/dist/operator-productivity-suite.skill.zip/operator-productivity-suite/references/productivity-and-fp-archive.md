# Operator Productivity, Office Compilers & FP/Go Archive (L2 Reference)

**Skill:** `operator-productivity-suite` (`U_12`, `U_13`, `U_14` · `ch-6-productivity-gtm`, `ch-7-fp-systems`)  
**Absorbed Skills:** `exec-thinking`, `exec-coach`, `usecase-forge`, `gtm`, `myinbox`, `inbox-ops`, `check-avail`, `morning`, `docx`, `pdf`, `pptx`, `xlsx`, `fp-ts`, `purify`, `typescript-fp`, `functional-programming`, `golang`, `go-tools`

---

## 1. `exec-thinking` & `exec-coach` — Executive Room Calculus

When drafting C-suite briefings, board memos, or architectural recommendations, replace generic consulting frameworks with the **Decision Calculus of the Room**:

1. **Downside Ownership Map:** Identify who holds budget authority, who owns operational P&L risk if the initiative slips, and who holds an organizational veto.
2. **Pyramid Principle Lead:** Open every executive artifact with the **Governing Verdict + 3 Quantified Proofs** in the first 120 words. Never bury the recommendation at the bottom of a chronological narrative.
3. **Pre-Mortem & Counter-Positioning (`exec-coach`):** For every strategic recommendation, explicitly state:
   - *The strongest technical or financial objection a skeptical VP/CFO will raise,*
   - *The falsifiable 30-day pilot metric that resolves that objection,*
   - *What we explicitly choose NOT to build in Phase 1.*

---

## 2. `usecase-forge` & `gtm` — Typed Enterprise Use-Case Engineering

Transform raw client pain points or market signals into a **Typed GTM Wedge Portfolio**:

| Layer | Required Schema | Example (Skill-Sheaf Meta-Controller) |
|---|---|---|
| **1. Pain Fiber** | `(Baseline Metric, Bottleneck Mechanism, Cost/Turn)` | `16,848 L0 tokens/turn` across 97 unindexed skills causing context rot & latency |
| **2. Operadic Workflow** | `Input -> Stage 1 -> Stage 2 -> Audited Output` | `Raw SKILL.md -> Skill-Sheaf Compiler -> 7 Master Routers -> 26-Gate Studio` |
| **3. Wedge 1: Land (Day 1–14)** | Low-friction diagnostic deliverable | Run `skill_sheaf_compiler.py` + `query_skill_sheaf.py --audit-cover` |
| **4. Wedge 2: Expand (Day 15–45)** | Production consolidation & CI gate | Package 7 Master `.skill.zip` bundles (`-98.3%` L0 token reduction) |
| **5. Wedge 3: Defend (Day 45–90)** | Institutional memory moat | Connect `--mcp` server + continuous `noether-wiki` research loop |

---

## 3. Unified Inbox & Calendar Triage (`myinbox` + `inbox-ops` + `check-avail` + `morning`)

This protocol consolidates four previously overlapping personal-productivity skills (`>70%` duplicate instructions) into a single deterministic 4-stage pipeline:

### Stage 1: Parallel Signal Harvest
- Query unread/starred messages from the last 72 hours alongside the next 7 business days of calendar commitments.
- Cross-reference sender identities against active project priorities in `STATUS.md` / `HANDOFF.md`.

### Stage 2: Priority Partitioning (`3 Buckets Only`)
1. **`F0 — Action Today (Blocking)`:** Direct questions from leadership, clients, or teammates blocking an active deliverable; calendar conflicts within 48h.
2. **`F1 — Strategic Leverage (48h Window)`:** GTM introductions, architecture reviews, scope sign-offs.
3. **`F2 — Archive / Delegate / FYI`:** Automated notifications, newsletters, CC threads with no action item.

### Stage 3: Conflict-Free Slot Proposal (`check-avail`)
- When scheduling meetings, always propose **3 concrete time windows** formatted with explicit day-of-week, date, start–end time, and timezone (`e.g., Thu Oct 22, 14:00–14:45 EDT / 11:00–11:45 PDT`), leaving a minimum 15-minute buffer around existing hard stops.

### Stage 4: Human-in-the-Loop Execution Floor (`A0`)
- Draft replies in clean, copy-ready blocks, but **never transmit external emails or mutate shared calendar invites without explicit user confirmation**.

---

## 4. Office Document Compilers (`docx`, `pdf`, `pptx`, `xlsx`)

When compiling binary office deliverables:
- **`docx` / `pdf`:** Use clean heading hierarchies (`H1..H3`), explicit table column widths, embedded vector/high-DPI figures (`>= 200 DPI`), and zero orphan headings at page breaks.
- **`pptx`:** Enforce WebAge / CETI visual density rules (`<= 35 words` per slide body, `Key Concept` / `Why It Matters` callouts, zero stacked callout boxes).
- **`xlsx`:** Use live Excel formulas (`SUM`, `INDEX/MATCH`, `XLOOKUP`) rather than hardcoded calculated values, freeze header panes, and format currencies/percentages explicitly.

---

## 5. Cold-Storage L2 Functional Programming & Go Archive (`ch-7-fp-systems`)

Because the legacy `fp-ts` (`1,366 lines`), `purify` (`1,240 lines`), `typescript-fp` (`965 lines`), `functional-programming` (`603 lines`), `golang` (`703 lines`), and `go-tools` (`582 lines`) skills consume **`~32,000 tokens`** combined, they are isolated from the active L0/L1 prompt budget and summarized below for immediate use:

### Core TypeScript FP Idioms (`fp-ts` / `purify-ts`)
- **Typed Error Channels (`Either<E, A>` / `TaskEither<E, A>`):**
  Replace `try/catch` and nullable returns with railway-oriented pipelines:
  ```typescript
  import { pipe } from 'fp-ts/function';
  import * as TE from 'fp-ts/TaskEither';
  import * as E from 'fp-ts/Either';

  export const loadAndValidateSheaf = (path: string): TE.TaskEither<AuditError, SheafKB> =>
    pipe(
      readFileTE(path),
      TE.chainEitherK(parseJsonE),
      TE.chainEitherK(validateContractE)
    );
  ```
- **Schema Codec Validation (`Codec<T>` in `purify-ts`):** Parse, don't validate—decode untrusted JSON at system boundaries into smart constructors (`NonEmptyString`, `BoundedFidelity`).

### Core Go Idioms (`golang` / `go-tools`)
- **Explicit Error Wrapping:** Always wrap errors with context (`fmt.Errorf("compile stalk %s: %w", stalkID, err)`) and inspect via `errors.Is` / `errors.As`.
- **Structured Concurrency:** Pass `context.Context` as the first argument to every I/O or subprocess function; bound parallel workers with `errgroup.WithContext(ctx)`.
- **On-Demand Full Archive Paths (Read ONLY When Writing Heavy `fp-ts` or `Go` Code):**
  - `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/fp-ts/SKILL.md`
  - `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/purify/SKILL.md`
  - `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/golang/SKILL.md`
