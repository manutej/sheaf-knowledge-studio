---
name: operator-productivity-suite
description: Master router for Executive Room Thinking, Use-Case Foraging, GTM Strategy, Inbox/Calendar Triage, Office Document Compilers (DOCX/PDF/PPTX/XLSX), and On-Demand FP/Go References.
---

# Operator Productivity & Document Suite (`operator-productivity-suite`)

Consolidates **21 Executive, Productivity, Document & Engineering Reference skills** (`stalk-12-executive-strategy-comms`, `stalk-13-document-artifact-engines`, `stalk-14-fp-systems-archive`) into a single L1 router, separating high-signal strategic workflows from low-frequency reference manuals.

---

## 1. High-Leverage Operator Workflows (Innovations Retained)

1. **Executive Room Dynamics & Operator Memory (`exec-thinking`, `exec-coach`):** Surfaces unsaid boardroom incentives, second-order power dynamics, and asymmetric trade-offs grounded in the operator's verified memory graph (`memory-os` / `sheaf-memory`).
2. **Operadic Use-Case Foraging & GTM (`usecase-forge`, `gtm`):** Maps prospect or domain signals into a typed Use-Case Map, scores 3 GTM wedges under adversarial red-teaming, and outputs an executable brief.
3. **Unified Inbox & Calendar Triage (`myinbox` + `inbox-ops` merged):** Consolidates duplicate email/calendar skills into one pass: `Fires | High-Leverage | Watch`, unanswered-thread detection, and timezone-safe slot proposals.
4. **Template-Bound Office Artifact Compilers (`docx`, `pdf`, `pptx`, `xlsx`, `proof`):** Deterministic Python/Node document builders paired with `artifact-chain` $m=1$ verification gates.

---

## 2. Progressive-Disclosure L2 Routing Table

| Sub-Task / Trigger | Constituent Skill(s) | L2 On-Demand Path |
|---|---|---|
| **Executive Room Synthesis / Coaching** | `exec-thinking`, `exec-coach` | `references/productivity-and-fp-archive.md` (§1) |
| **Prospect Use-Case Map / GTM Wedge** | `usecase-forge`, `gtm` | `references/productivity-and-fp-archive.md` (§2) · `~/.grok/skills/usecase-forge/SKILL.md` |
| **Inbox & Calendar Triage Routine** | `myinbox`, `inbox-ops`, `morning` | `references/productivity-and-fp-archive.md` (§3) |
| **Word / PDF / PowerPoint / Excel Build** | `docx`, `pdf`, `pptx`, `xlsx` | `references/productivity-and-fp-archive.md` (§4) · `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/{docx,pdf,pptx,xlsx}/SKILL.md` |
| **Collaborative Proof Docs (`proofeditor.ai`)** | `proof` | `~/.grok/skills/proof/SKILL.md` |
| **Typed FP (`fp-ts`, `purify`) & Go Archive** | `fp-ts`, `purify`, `typescript-fp`, `golang` | `references/productivity-and-fp-archive.md` (§5 — Load ONLY on explicit FP/Go tasks) |
