# 4-Tier Progressive Disclosure & Skill Consolidation Specification (L2 Reference)

**Skill:** `agy-skill-foundry` (`U_03` · `ch-1-meta-operadic`)  
**Enforcement Gate:** `scripts/package_and_lint_skill.py` (`HF-SKILL-01` .. `HF-SKILL-07`)

---

## 1. Token Budget Mathematics & Empirical Compression Law

Every skill loaded into an agent's active discovery directory (`.agents/skills/`, `~/.claude/skills/`, or `~/.grok/skills/`) imposes two distinct context costs:
1. **Per-Turn Router Cost ($C_{\mathrm{L0}}$):** The YAML frontmatter (`name` + `description`) injected into the system prompt on **every single turn** of the conversation.
2. **Activation Cost ($C_{\mathrm{L1}}$):** The full `SKILL.md` markdown body read into context when the agent activates the skill.

### Empirical Ecosystem Benchmark (81-Skill Corpus)
| Tier | Unconsolidated Baseline (81 Skills) | Consolidated 7-Master-Skill Architecture | Token Delta |
|---|---|---|---|
| **`L0` System Router** (`name` + `description`) | `~16,607 tokens / turn` | **`294 tokens / turn`** (`<= 45 tokens` $\times 7$) | **$-98.2\%$ every turn** |
| **`L1` Active `SKILL.md` Body** | `~286,362 tokens` (`1,145 KB`) | **`~3,150 tokens`** (`36–80 lines` $\times 7$) | **$-98.9\%$ body footprint** |
| **`L2` Reference Leaves** (`references/*.md`) | Inlined inside monolithic `SKILL.md` | **On-Demand Only** (`>= 80 lines` per leaf, loaded only when routed) | **$0$ idle tokens** |
| **`L3` Executable Scripts** (`scripts/*.py`) | Often re-emitted as LLM code blocks | **Zero-Token CLI / MCP Execution** (`--mcp` or `python3 scripts/...`) | **$0$ prompt tokens** |

---

## 2. The 4-Tier Progressive Disclosure Architecture

### Tier `L0`: System Prompt Discovery Header (`<= 45 tokens`, `<= 260 chars`)
- **Purpose:** Enable the LLM router to decide *whether* to read `SKILL.md` without paying for procedural details on turns where the skill is unused.
- **Format Contract:**
  ```yaml
  ---
  name: kebab-case-skill-id
  description: Master router for [3-6 concrete domain nouns/triggers]. Use when [1-sentence trigger condition].
  ---
  ```
- **Hard Invariant (`HF-SKILL-01`, `HF-SKILL-02`):** Must parse as valid YAML with non-empty `name` and `description`. `len(description) <= 260` characters (`~45 tokens`). Never list multi-sentence workflows, CLI flags, or historical background in `description`.

### Tier `L1`: Master Router & Fast-Path `SKILL.md` (`<= 80 lines`)
- **Purpose:** Act as a compact **Categorical Pullback Router** that maps user intent onto:
  1. The exact sub-capability or absorbed legacy skill inside the domain sheaf,
  2. The specific `L2` reference leaf (`references/<leaf>.md`) to view if deep schemas/rubrics are required,
  3. The exact `L3` deterministic script (`scripts/<tool>.py`) or MCP tool to run.
- **Required Sections in Every `L1` Master `SKILL.md`:**
  1. **Title & 1-Sentence Mission**
  2. **Categorical Routing Table (`Sub-Capability | Absorbed Legacy Skills | Primary Action / Reference Path`)**
  3. **Progressive Disclosure Protocol (3–4 bullet execution contract)**
  4. **Fast-Path CLI / MCP Commands**
- **Hard Invariant (`HF-SKILL-03`):** Total line count of `SKILL.md` must satisfy `L <= 80` lines.

### Tier `L2`: Self-Contained Operational Specifications (`references/*.md`, `>= 80 lines`)
- **Purpose:** Hold deep mathematical formulations, JSON schemas, CSS token tables, rubric checklists, and domain edge cases that would bloat `L1` if loaded unconditionally.
- **Hard Invariant (`HF-SKILL-06`, `HF-SKILL-07`):**
  - Every `references/...` path cited in `SKILL.md` must exist on disk (`0` dead links).
  - Every `L2` reference file in a consolidated Master Skill must be **substantive and self-contained (`>= 80 lines`)** so the agent never has to fall back to hunting deprecated `~/.claude/skills/synced/` directories during normal execution.

### Tier `L3`: Zero-Token Deterministic Engines (`scripts/*.py`, `scripts/*.mjs`)
- **Purpose:** Offload indexing, cohomology auditing, contract linting, TTS synthesis, and archive packaging to deterministic code.
- **Execution Modes:**
  - **CLI Mode:** Invoked via `run_command` with structured `--json` or file output.
  - **MCP Stdio Mode:** Exposed via `query_skill_sheaf.py --mcp` (`sheaf_query`, `sheaf_inspect_stalk`, `sheaf_read_page`, `skill_sheaf_route`, `skill_sheaf_inspect_stalk`, `skill_sheaf_read_skill`).

---

## 3. Categorical Consolidation Workflow (Many-to-One Skill Morphism)

When consolidating $N$ overlapping skills into a single Master Skill Router $M$:

1. **Induce Domain Open Cover:**
   Group candidate skills by shared output surface and mathematical/operational invariant (never by alphabetical name).
2. **Extract the Shared Invariant Spine (`L1`):**
   Identify the 4–8 orthogonal sub-capabilities across the $N$ skills and build the `L1` Markdown routing table in `.agents/skills/<master-skill>/SKILL.md`.
3. **Distill Union of Non-Trivial Mechanics into `L2` (`references/*.md`):**
   Preserve every unique formula, gate ID (`HF-*`), anti-pattern (`AP-*`), and command signature from the $N$ source skills inside structured `references/*.md` manuals.
4. **Verify Restriction Fidelity ($f_{ij} \ge 0.85$):**
   Run `portable-toolkit/4-skill-sheaf-meta-controller/skill_sheaf_compiler.py --out skill-sheaf-kb` to recompute empirical Čech cohomology across the 14 Master Stalks (`U_01..U_14`).
5. **Lint & Package (`package_and_lint_skill.py`):**
   ```bash
   python3 .agents/skills/agy-skill-foundry/scripts/package_and_lint_skill.py \
     .agents/skills/<master-skill> \
     --package-dir portable-toolkit/4-skill-sheaf-meta-controller/dist
   ```

---

## 4. Binary Quality Gates (`HF-SKILL-01` .. `HF-SKILL-07`)

| Gate ID | Check | Threshold / Criterion | Failure Severity |
|---|---|---|---|
| `HF-SKILL-01` | YAML Frontmatter Validity | Valid `---` block with `name` and `description` | `P0 Blocker` |
| `HF-SKILL-02` | `L0` Router Budget | `len(description) <= 260` chars (`~45 tokens`) | `P0 Blocker` |
| `HF-SKILL-03` | `L1` Body Line Cap | `SKILL.md` total lines `<= 80` (or `--max-l1-lines`) | `P0 Blocker` |
| `HF-SKILL-04` | No Unclosed Code Fences | Even number of triple-backtick fences in `SKILL.md` & `references/*.md` | `P0 Blocker` |
| `HF-SKILL-05` | Zero AI-Slop Tells | Zero banned phrases (`seamlessly`, `game-changer`, `delve into`, `in conclusion`) | `P1 Major` |
| `HF-SKILL-06` | Reference & Script Link Integrity | Every `references/*` and `scripts/*` path in `SKILL.md` resolves on disk | `P0 Blocker` |
| `HF-SKILL-07` | `L2` Operational Depth | Every linked `references/*.md` file has `>= 80` lines of substantive spec | `P1 Major` |
