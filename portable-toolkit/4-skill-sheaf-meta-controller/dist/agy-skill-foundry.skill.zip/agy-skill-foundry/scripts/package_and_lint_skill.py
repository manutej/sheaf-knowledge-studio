#!/usr/bin/env python3
r"""
package_and_lint_skill.py
=========================
Deterministic 6-Gate Linter & Portable Zip Packager for Antigravity / Argon Skills.
Enforces 4-tier progressive disclosure (HF-SKILL-01..06):
  - HF-SKILL-01: Valid YAML frontmatter (`name` kebab-case, `description` non-empty)
  - HF-SKILL-02: L0 Frontmatter Token Budget (`len(description) <= 260` chars / `<= 65` tokens)
  - HF-SKILL-03: L1 SKILL.md Line Budget (`lines <= 95` for Master/Standard skills)
  - HF-SKILL-04: L2/L3 Reference & Script Path Resolution (all relative links exist)
  - HF-SKILL-05: Zero Conversational Slop / Bloat Phrases
  - HF-SKILL-06: Clean Portable Archive Packaging (`.skill.zip`)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path

BANNED_BLOAT_PHRASES = [
    "cool? cool.",
    "just vibe with me",
    "inspiring plumbers to open up their terminals",
    "if you haven't heard",
]


def lint_skill_directory(skill_dir: Path, max_lines: int = 95, max_desc_chars: int = 260) -> dict:
    skill_md = skill_dir / "SKILL.md"
    gates = {}
    violations = []

    def record(gid: str, ok: bool, detail: str):
        gates[gid] = {"status": "CLEARED" if ok else "OPEN", "detail": detail}
        if not ok:
            violations.append(f"[{gid}] {detail}")

    if not skill_md.is_file():
        record("HF-SKILL-01", False, f"Missing SKILL.md in {skill_dir}")
        return {"skill_dir": str(skill_dir), "status": "FAIL", "gates": gates, "violations": violations}

    text = skill_md.read_text(encoding="utf-8")
    lines = text.count("\n") + 1

    # HF-SKILL-01: YAML frontmatter
    m_fm = re.search(r"^---\s*\n(.*?)\n---", text, re.S)
    name_val = ""
    desc_val = ""
    if m_fm:
        fm = m_fm.group(1)
        mn = re.search(r"^name:\s*([a-z0-9-]+)\s*$", fm, re.M)
        if mn:
            name_val = mn.group(1).strip()
        md = re.search(r"description:\s*(?:[>|]-?\s*\n)?(.*?)(?:\n[a-zA-Z_-]+:|\Z)", fm, re.S)
        if md:
            desc_val = " ".join(md.group(1).split()).strip("\"'")

    record(
        "HF-SKILL-01",
        bool(name_val and desc_val and name_val == skill_dir.name),
        f"Frontmatter name='{name_val}' matches folder '{skill_dir.name}', description present ({len(desc_val)} chars)"
    )

    # HF-SKILL-02: L0 Token Budget
    l0_tokens = (len(name_val) + len(desc_val)) // 4
    record(
        "HF-SKILL-02",
        0 < len(desc_val) <= max_desc_chars,
        f"L0 frontmatter description={len(desc_val)} chars (~{l0_tokens} tokens, cap={max_desc_chars} chars)"
    )

    # HF-SKILL-03: L1 Body Line Budget
    l1_tokens = len(text.encode("utf-8")) // 4
    record(
        "HF-SKILL-03",
        lines <= max_lines,
        f"L1 SKILL.md body={lines} lines (~{l1_tokens} tokens, cap={max_lines} lines)"
    )

    # HF-SKILL-04: Relative link resolution (only skill-local relative paths not preceded by '/')
    rel_refs = re.findall(r"(?<![A-Za-z0-9_./-])((?:references|scripts|assets)/[A-Za-z0-9_./-]+)", text)
    missing_refs = []
    checked_md_refs = []
    thin_md_refs = []
    for rel in sorted(set(rel_refs)):
        clean_rel = rel.rstrip(".,;:)`'\"")
        if "*" in clean_rel or "<" in clean_rel or clean_rel.endswith("/"):
            continue
        target_p = skill_dir / clean_rel
        if not target_p.exists():
            missing_refs.append(clean_rel)
        elif clean_rel.startswith("references/") and clean_rel.endswith(".md") and target_p.is_file():
            ref_lines = target_p.read_text(encoding="utf-8", errors="ignore").count("\n") + 1
            checked_md_refs.append((clean_rel, ref_lines))
            if ref_lines < 80:
                thin_md_refs.append(f"{clean_rel} ({ref_lines}L < 80L)")
    record(
        "HF-SKILL-04",
        len(missing_refs) == 0,
        f"Checked {len(set(rel_refs))} L2/L3 paths; missing={len(missing_refs)}" + (f" ({missing_refs})" if missing_refs else "")
    )

    # HF-SKILL-05: Zero conversational bloat
    low = text.lower()
    found_bloat = [p for p in BANNED_BLOAT_PHRASES if p in low]
    record(
        "HF-SKILL-05",
        len(found_bloat) == 0,
        f"Zero conversational bloat phrases detected (found={len(found_bloat)})"
    )

    # HF-SKILL-07: L2 Reference Operational Depth (>= 80 lines per linked references/*.md)
    ref_summary = ", ".join(f"{r}:{ln}L" for r, ln in checked_md_refs) if checked_md_refs else "no linked references/*.md"
    record(
        "HF-SKILL-07",
        len(thin_md_refs) == 0,
        f"L2 reference depth verified ({ref_summary})" if not thin_md_refs else f"Thin L2 references: {thin_md_refs}"
    )

    return {
        "skill": name_val or skill_dir.name,
        "status": "PASS" if not violations else "FAIL",
        "l0_tokens": l0_tokens,
        "l1_lines": lines,
        "l1_tokens": l1_tokens,
        "l2_references": checked_md_refs,
        "gates": gates,
        "violations": violations
    }


def package_skill_zip(skill_dir: Path, out_zip: Path) -> Path:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(skill_dir.rglob("*")):
            if p.is_file() and not p.name.startswith(".") and "__pycache__" not in p.parts:
                arcname = f"{skill_dir.name}/{p.relative_to(skill_dir)}"
                zf.write(p, arcname)
    return out_zip


MASTER_7_SKILLS = [
    "agy-skill-foundry",
    "operadic-meta-suite",
    "sheaf-research-memory",
    "editorial-design-studio",
    "ceti-explainer",
    "adversarial-moe-governance",
    "operator-productivity-suite",
]


def main():
    parser = argparse.ArgumentParser(description="Lint and Package Antigravity Skills (HF-SKILL-01..07)")
    parser.add_argument("--skill-dir", type=Path, default=None, help="Path to single skill folder")
    parser.add_argument("--package-out", type=Path, default=None, help="Optional output .skill.zip path")
    parser.add_argument("--max-lines", type=int, default=95, help="Max lines for L1 SKILL.md")
    parser.add_argument("--batch-master-skills", action="store_true", help="Lint and package all 7 Consolidated Master Skills")
    args = parser.parse_args()

    if args.batch_master_skills:
        root = Path(__file__).resolve().parents[4]
        skills_root = root / ".agents" / "skills"
        dist_a = root / "portable-toolkit" / "4-skill-sheaf-meta-controller" / "dist"
        dist_b = root / "dist"
        all_ok = True
        for sname in MASTER_7_SKILLS:
            sdir = skills_root / sname
            res = lint_skill_directory(sdir, max_lines=args.max_lines)
            if res["status"] == "PASS":
                zp_a = package_skill_zip(sdir, dist_a / f"{sname}.skill.zip")
                zp_b = package_skill_zip(sdir, dist_b / f"{sname}.skill.zip")
                res["gates"]["HF-SKILL-06"] = {
                    "status": "CLEARED",
                    "detail": f"Packaged {zp_a.name} ({round(zp_a.stat().st_size/1024, 1)} KB) -> {dist_a.relative_to(root)} & {dist_b.relative_to(root)}"
                }
            else:
                all_ok = False
                res["gates"]["HF-SKILL-06"] = {"status": "OPEN", "detail": "Fix open gates before packaging"}
            print(f"=== SKILL FOUNDRY AUDIT [{res['skill']}]: {res['status']} (L0={res.get('l0_tokens')}t, L1={res.get('l1_lines')}L/{res.get('l1_tokens')}t) ===")
            for gid in sorted(res["gates"].keys()):
                g = res["gates"][gid]
                print(f"  [{'PASS' if g['status']=='CLEARED' else 'FAIL'}] {gid}: {g['detail']}")
        sys.exit(0 if all_ok else 1)

    if not args.skill_dir:
        parser.error("Either --skill-dir or --batch-master-skills is required")

    res = lint_skill_directory(args.skill_dir, max_lines=args.max_lines)
    if args.package_out and res["status"] == "PASS":
        zp = package_skill_zip(args.skill_dir, args.package_out)
        res["gates"]["HF-SKILL-06"] = {
            "status": "CLEARED",
            "detail": f"Packaged {zp.name} ({round(zp.stat().st_size/1024, 1)} KB)"
        }
    else:
        res["gates"]["HF-SKILL-06"] = {
            "status": "CLEARED" if res["status"] == "PASS" else "OPEN",
            "detail": "Ready for packaging" if res["status"] == "PASS" else "Fix open gates before packaging"
        }

    print(f"=== SKILL FOUNDRY AUDIT [{res['skill']}]: {res['status']} (L0={res.get('l0_tokens')}t, L1={res.get('l1_lines')}L/{res.get('l1_tokens')}t) ===")
    for gid in sorted(res["gates"].keys()):
        g = res["gates"][gid]
        print(f"  [{'PASS' if g['status']=='CLEARED' else 'FAIL'}] {gid}: {g['detail']}")
    sys.exit(0 if res["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()

