---
name: agy-skill-foundry
description: Create, refactor, lint, and package Antigravity & Argon skills using 4-tier progressive disclosure (L0 <= 45 tokens, L1 <= 80 lines, L2 references, L3 scripts) and register them in the Skill Sheaf Graph Memory.
---

# Antigravity & Argon Skill Foundry (`agy-skill-foundry`)

Replaces bloated, conversational skill-creation workflows with a deterministic, token-disciplined **4-Tier Progressive Disclosure Architecture** designed specifically for **Antigravity (AGY)** and **Argon** agents.

---

## 1. The 4-Tier Progressive Disclosure Law (Non-Negotiable)

| Tier | Artifact | Token / Line Cap | When Loaded | Purpose |
|---|---|---|---|---|
| **L0** | `SKILL.md` YAML Frontmatter (`name`, `description`) | **`≤ 45 tokens`** (`≤ 180 chars`) | Every turn (System Prompt) | Crisp, high-discriminability routing trigger. Never write 100-word "pushy" paragraphs. |
| **L1** | `SKILL.md` Body (Entrypoint & Routing Map) | **`≤ 80 lines`** (`≤ 800 tokens`) | Only when skill is activated | Core invariants, 3–5 step workflow, and L2/L3 routing table. Zero conversational filler. |
| **L2** | `references/<sub-skill-or-spec>.md` | Modular (`100–300 lines` each) | Only when specific sub-workflow is needed | Detailed domain schemas, style masters, API catalogs, or consolidated leaf skills. |
| **L3** | `scripts/<deterministic_tool>.py` | **`0 prompt tokens`** (executed via CLI/MCP) | Executed via `run_command` or MCP | Mechanical compilers, linters, evaluators, and packagers. Never make the LLM hand-simulate what a 50-line script can verify. |

---

## 2. Canonical Directory Structure

Place workspace skills in `.agents/skills/<skill-name>/` or global skills in `~/.gemini/config/skills/<skill-name>/`:

```text
.agents/skills/<skill-name>/
├── SKILL.md                  # L0 frontmatter (≤45t) + L1 router body (≤80L)
├── references/               # L2 on-demand deep specs & consolidated sub-skills
│   └── <sub-domain>.md
└── scripts/                  # L3 zero-token deterministic compilers & gates
    └── verify_<skill>.py
```

---

## 3. Operational Workflow (`P0 → P3`)

### P0 — Sheaf Graph Lookup (Prevent Duplicate Skills)
Before creating a new skill, check whether it belongs as an **L2 reference leaf** inside one of the 7 Consolidated Master Skills:
```bash
python3 portable-toolkit/4-skill-sheaf-meta-controller/query_skill_sheaf.py --route "<proposed skill capability>"
```
- If an existing Master Stalk covers the domain with restriction fidelity $f_{ij} \ge 0.55$, add a `references/<leaf>.md` file to that Master Skill and add 1 row to its L1 routing table instead of minting a new top-level L0 skill.

### P1 — Scaffold or Refactor via Deterministic Script
Run `scripts/package_and_lint_skill.py` to scaffold, audit, or package a skill:
```bash
python3 .agents/skills/agy-skill-foundry/scripts/package_and_lint_skill.py \
  --skill-dir .agents/skills/<skill-name> \
  --package-out dist/<skill-name>.skill.zip
```

### P2 — Enforce the 6 Binary Skill-Foundry Gates (`HF-SKILL-01..06`)
- `HF-SKILL-01`: Valid YAML frontmatter with `name` (kebab-case) and `description`.
- `HF-SKILL-02`: **L0 Token Budget**: `description` length $\le 220$ chars ($\le 55$ tokens).
- `HF-SKILL-03`: **L1 Body Budget**: `SKILL.md` line count $\le 95$ lines ($\le 1,000$ tokens).
- `HF-SKILL-04`: **L2 Reference Resolution**: Every relative link (such as `references/progressive-disclosure-spec.md` or `scripts/package_and_lint_skill.py`) in `SKILL.md` resolves to an existing file on disk.
- `HF-SKILL-05`: **Zero Conversational Bloat**: Zero second-person chatty filler or informal conversational asides.
- `HF-SKILL-06`: **Sheaf Index Registration**: Rebuild `skill-sheaf-kb` via `skill_sheaf_compiler.py` and verify `12/12` `HF-SHEAF` gates pass.
