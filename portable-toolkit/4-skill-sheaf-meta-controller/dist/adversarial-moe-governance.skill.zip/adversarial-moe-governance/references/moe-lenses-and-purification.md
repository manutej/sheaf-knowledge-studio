# Adversarial MOE Lenses, Tell-Apart Discriminability & Purification (L2 Reference)

**Skill:** `adversarial-moe-governance` (`U_10`, `U_11` · `ch-5-eval-governance`)  
**Absorbed Skills:** `courseware-adversarial-loop`, `courseware-standards`, `anti-patterns-courseware`, `tell-apart`, `claude-exorcist`, `ormus`

---

## 1. The 4-Lens Adversarial Mixture-of-Experts (`A1–A4`)

Every production corpus, sheaf knowledge base, skill ecosystem, or courseware build is audited by four orthogonal red-team lenses that emit structured findings (`P0 Blocker`, `P1 Major`, `P2 Craft`):

| Lens | Role | Primary Invariants Audited | Hard Gates Enforced |
|---|---|---|---|
| **`A1`** | **Mathematical, Cohomological & Technical Depth** | Non-trivial formal laws ($\ge 95\%$ stalks), empirical Čech cohomology ($\|\delta^0 s\|_{ij} = 1 - f_{ij}$), 2-simplex holonomy ($\|\delta^1 \omega\|_{ijk} \le 0.35$), `h1_obstruction` presence, zero placeholder math | `HF-SHEAF-04`, `HF-SHEAF-05`, `HF-SHEAF-06`, `HF-SHEAF-11`, `HF-SHEAF-12` |
| **`A2`** | **Enterprise Systems, Token Economics & MCP Integrity** | 4-tier progressive disclosure (`L0 <= 45 tokens`, `L1 <= 80 lines`), MCP JSON-RPC 2.0 tool parity (`sheaf_query`, `sheaf_inspect_stalk`, `sheaf_read_page`), CLI flag completeness, zero client/PMI leak | `HF-SHEAF-01..03`, `HF-MCP-01`, `HF-CONTRACT-01`, `HF-SKILL-01..03` |
| **`A3`** | **Editorial Visual Craft, Typography & Studio UX** | Deferred bundle loading (`< 500 KB`), all 5 plates functional, zero raw LaTeX backslashes, non-color-alone status stamps (`◆`, `⚖`, `⊘`), zero template bleed (`HF-STUDIO-09`), dynamic blueprint (`HF-STUDIO-10`), custom podcast turns (`HF-STUDIO-11`) | `HF-STUDIO-01` .. `HF-STUDIO-11` |
| **`A4`** | **Citation Verifiability, Contract Parity & Anti-Slop** | Verbatim page/file anchors (`>= 95%` formal items), neural dual-host podcast audio (`HF-SHEAF-13`), zero dead links in `SKILL.md` (`HF-SKILL-06`), substantive `L2` references (`>= 80` lines, `HF-SKILL-07`), zero AI-slop tells | `HF-SHEAF-07..10`, `HF-SHEAF-13`, `HF-SKILL-04..07` |

---

## 2. Multi-Round Monotonic Convergence Protocol (`R1 -> R2 -> R3`)

1. **Deterministic Gate Runner First:**
   Always run the automated gate suites before invoking LLM evaluators so LLM tokens are never wasted diagnosing syntax or schema errors:
   ```bash
   python3 .agents/skills/sheaf-knowledge-pipeline/scripts/run_sheaf_pipeline_audit.py \
     --kb skill-sheaf-kb/data/sheaf_kb.json \
     --html "Skill Ecosystem Sheaf Meta-Controller - Studio.html" \
     --query-script skill-sheaf-kb/query_sheaf.py \
     --contract-doc skill-sheaf-kb/TYPED-CONTRACT-SHEAF-META-PROMPT.md \
     --out skill-sheaf-kb/adversarial-eval/rN_moe_audit.json
   ```
2. **Monotonic Violation Contraction Law:**
   Let $V(r)$ be the multiset of open `P0/P1/P2` defects at round $r$. Every repair pass must satisfy:
   $$|V(r)| < |V(r-1)| \quad \text{and} \quad |V_{\mathrm{P0}}(r)| = 0 \;\;\text{before lock-in.}$$
3. **Persistent QC Memory Compounding:**
   After every adversarial round, append the empirical scorecard to:
   - `portable-toolkit/META-LEARNING-LOG.md`
   - `wiki/qc-memory/FINDINGS-YYYY-MM-DD-*.md`
   - `wiki/LEDGER.md`

---

## 3. `tell-apart` — Representation Discriminability Kernel ($\ker(r) \subseteq \ker(d)$)

Given a system state space $X$, a representation or test suite $r : X \to Y$, and an operational decision map $d : X \to D$ (e.g., `SHIP` vs. `BLOCK`):

### The Discriminability Invariant
$$\forall x_1, x_2 \in X:\quad d(x_1) \neq d(x_2) \implies r(x_1) \neq r(x_2)$$
Equivalently, $\ker(r) \subseteq \ker(d)$. A dashboard card, linter gate, or status badge that produces the same output (`PASS` / green) on both a valid artifact $x_{\mathrm{good}}$ and a defective artifact $x_{\mathrm{bad}}$ violates `tell-apart`.

### Mandatory Negative-Selftest Protocol (`--selftest`)
Every contract linter (`corpus_contract_linter.py`) must implement `--selftest`, which clones a valid payload in memory and injects deliberate mutations (missing fiber pages, hardcoded formula `0.96 + 0.008 * k`, missing `h1_obstruction`, broken page range) and asserts that each mutation triggers the exact expected `HF-*` failure code.

---

## 4. `claude-exorcist` — Anti-Slop & AI-Theater Purification

Strip all forms of generative AI padding and decorative theater across prose, code, and UI:

| Slop Category | Forbidden Pattern (`AP-*`) | Required Replacement |
|---|---|---|
| **Hyperbolic Adjectives (`AP-PROSE-01`)** | *"seamlessly"*, *"revolutionary"*, *"game-changing"*, *"delve into"*, *"testament to"* | Concrete quantitative delta (`-98.3% L0 tokens`, `26/26 gates cleared`) |
| **Decorative Telemetry (`AP-DATA-01`)** | Hardcoded linear ramps (`0.96 + 0.008 * k`), fake progress bars, static mock badges | Empirical TF-IDF + Jensen-Shannon + Jaccard cohomology computed from actual text |
| **Callout Stacking (`AP-SLIDE-02`)** | *"So What:"*, stacked boxes without narrative bridge, bolded Learning Objectives | Strictly `Key Concept` / `Why It Matters`; plain-text measurable LOs |
| **Dead Controls (`AP-UI-01`)** | Buttons, search bars, or sliders that do not mutate DOM state | Wired event handlers verified by `verify_studio_gates.py` |

---

## 5. `ormus` — Hermetic Software Engineering Invariants

1. **Pure Core, Imperative Shell:** Separate pure mathematical/schema transformations (`sheaf_induction_engine.py`) from file I/O and subprocess CLI wrappers.
2. **Total Functions Over Partial Functions:** Handle missing optional packages (e.g., `edge_tts` fallback to macOS `/usr/bin/say` + `ffmpeg`) deterministically with explicit diagnostics rather than uncaught tracebacks.
3. **Idempotent Rebuilds:** Running the compiler pipeline twice on the same inputs must preserve synthesized audio metadata and converge to identical gate results.


---

## 6. Canonical Adversarial Finding Schema (`rN_moe_audit.json`)

Every adversarial evaluation round (`R1`, `R2`, `R3`) must emit a machine-verifiable JSON scorecard conforming to this exact schema:

```json
{
  "overall_verdict": "GO",
  "cleared_gates": 26,
  "total_gates": 26,
  "agents": {
    "A1_Depth_Olog_Cohomology": { "verdict": "GO", "cleared": 8, "total": 8 },
    "A2_Performance_FTS5_MCP_Contract": { "verdict": "GO", "cleared": 6, "total": 6 },
    "A3_FieldManual_Math_SymbolicCraft": { "verdict": "GO", "cleared": 7, "total": 7 },
    "A4_Citations_PageFibers_Wiki": { "verdict": "GO", "cleared": 5, "total": 5 }
  }
}
```

### Mandatory Pre-Commit Verification Sequence
1. `python3 .agents/skills/agy-skill-foundry/scripts/package_and_lint_skill.py --batch-master-skills --max-lines 80`
2. `python3 portable-toolkit/2-json-contract-linter/corpus_contract_linter.py --selftest`
3. `python3 .agents/skills/sheaf-knowledge-pipeline/scripts/run_sheaf_pipeline_audit.py --kb skill-sheaf-kb/data/sheaf_kb.json --html "Skill Ecosystem Sheaf Meta-Controller - Studio.html" --query-script skill-sheaf-kb/query_sheaf.py --contract-doc skill-sheaf-kb/TYPED-CONTRACT-SHEAF-META-PROMPT.md --out skill-sheaf-kb/adversarial-eval/r3_moe_audit.json`
