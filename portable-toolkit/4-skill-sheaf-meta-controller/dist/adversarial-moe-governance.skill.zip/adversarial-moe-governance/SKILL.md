---
name: adversarial-moe-governance
description: Master router for A1-A4 Adversarial MOE Red-Teaming, Tell-Apart Discriminability Audits, Calcinate AI-Slop Purification, and Production Guardrails.
---

# Adversarial MOE Governance (`adversarial-moe-governance`)

Consolidates **6 Evaluation, Purification & Safety skills** (`stalk-10-adversarial-moe-evaluation`: `moe-eval`, `multi-agent-eval`, `tell-apart`, `claude-exorcist`, `ormus`, `dev-only-no-prod`) into a single deterministic quality-gate controller.

---

## 1. The 4 Orthogonal MOE Evaluator Lenses (`A1–A4`)

| Lens | Focus | Hard-Fail Invariant |
|---|---|---|
| **A1 · Depth & Cohomology** | Mathematical/technical rigor, local Ologs, $\check{H}^0/\check{H}^1$ gluing, OC consistency | No hand-waved formulas; restriction fidelity $f_{ij}$ and holonomy $\|\delta^1\|$ must be content-computed. |
| **A2 · Systems & Enterprise** | Performance (`<450 KB` HTML), SQLite FTS5 parity, MCP JSON-RPC 2.0, AI AUP & zero client leak | Zero production hot-fixes (`dev-only-no-prod`); zero client/PMI leakage on learner surfaces. |
| **A3 · Visual & Editorial Craft** | Bertin hierarchy, zero raw LaTeX leakage, non-stacked callouts, collision-free SVG bounding boxes | `Key Concept` / `Why It Matters` only (never `So What`); zero GenAI hype/slop tells. |
| **A4 · Citations & Discriminability** | Exact `[p. N]` page-fiber bounds, `100%` body coverage, `tell-apart` decision kernel | Every number, theorem, and quote resolves to a verified source locator. |

---

## 2. Progressive-Disclosure L2 & L3 Routing Table

| Sub-Task / Trigger | L2 Reference / Skill Path | L3 Executable Gate |
|---|---|---|
| **Run 22-Gate Sheaf & Studio Audit** | `references/moe-lenses-and-purification.md` (§1) | `portable-toolkit/3-gate-review-runner/gate_review_runner.py` |
| **Tell-Apart Representation Audit** | `references/moe-lenses-and-purification.md` (§2) | `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/tell-apart/SKILL.md` |
| **Purge AI Theater & Slop (`exorcist`)** | `references/moe-lenses-and-purification.md` (§3) | `~/.grok/skills/claude-exorcist/SKILL.md` |
| **HermeticOrmus Engineering Discipline** | `references/moe-lenses-and-purification.md` (§4) | `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/ormus/SKILL.md` |
| **Production Safety Guardrail** | `~/.grok/skills/dev-only-no-prod/SKILL.md` | Read-only SSH on prod; write only to local DEV. |
