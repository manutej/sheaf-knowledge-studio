---
name: operadic-meta-suite
description: Master router for the Operadic & Meta-Cognitive Suite (meta-operad, op-consist, operadic-interview, meta-planning, meta-prompting, meta-mvp, split-work-rejoin, artifact-chain, noether-harness).
---

# Operadic & Meta-Cognitive Suite (`operadic-meta-suite`)

Consolidates **11 Meta & Operadic skills** (`stalk-01-operadic-composition` + `stalk-02-meta-planning-chains`) into a single L1 Master Router with progressive disclosure.

---

## 1. Core Algebraic Invariants

1. **Colored Operad Decomposition (`TREE` + `COMPOSE`):** Every multi-step plan, prompt chain, or workflow is a rooted tree of typed operations $f : (c_1, \dots, c_k) \to c_0$. Composing all nodes must reproduce the root task (`COMPOSE` witness).
2. **Parallel Lane Law:** Substitution into disjoint slots commutes. Two sub-agents or lanes touching the *same* mutable slot may never run in parallel.
3. **Operadic Consistency (`OC` Gate):** Compare the composed tree evaluation against a partial or total collapse (`Tier 1 = 2 calls`). Disagreement localizes the exact broken edge (inconsistency kernel) without ground-truth labels.
4. **Hopf Split-Work-Rejoin (`Δ → Work → m`):** Every parallel split (`Δ`) must declare its typed seam contract and counit check (`ε`) before rejoining (`m`).

---

## 2. Progressive-Disclosure L2 Routing Table

Load **only** the specific L2 reference or leaf skill required for the current task:

| Sub-Task / Trigger | Constituent Skill | L2 Reference / On-Demand Path |
|---|---|---|
| **Operadic Tree & OC Gate** | `meta-operad`, `op-consist` | `references/operadic-catalog.md` (§1) · `~/.grok/skills/meta-operad/SKILL.md` |
| **N-Level Typed Question Tree** | `operadic-interview` | `references/operadic-catalog.md` (§2) · `~/.grok/skills/operadic-interview/SKILL.md` |
| **Typed Meta-Plan before Execution** | `meta-planning` | `references/operadic-catalog.md` (§3) · `~/.grok/skills/meta-planning/SKILL.md` |
| **Reusable Meta-Prompt / MVP Bundle** | `meta-prompting`, `meta-mvp` | `references/operadic-catalog.md` (§4) · `~/.grok/skills/meta-mvp/SKILL.md` |
| **30+ Slide / Long Deliverable Chain** | `artifact-chain` | `.agents/skills/artifact-chain/SKILL.md` |
| **Hopf Parallel Split → Rejoin** | `split-work-rejoin` | `references/operadic-catalog.md` (§5) |
| **Conservation-Law Coding Harness** | `noether-harness`, `category-master` | `references/operadic-catalog.md` (§6) |

---

## 3. Execution Procedure (`5 Moves`)

1. **LIFT (`TREE`):** Decompose the task into typed nodes `(input_types) -> output_type`. Reject any untyped edge before spending inference.
2. **WITNESS (`COMPOSE`):** Verify that collapsing the tree reproduces the original prompt.
3. **EXECUTE (`m=1` Lanes):** Run disjoint slots in parallel; checkpoint intermediate artifacts to disk (`STATUS.md` / `HANDOFF.md`).
4. **CHECK (`OC` + Gate):** Run Tier-1 collapse verification or mechanical script gates on WITNESS, INTERFACE, and VERIFICATION edges.
5. **VALUATE:** Compute confidence (weakest-link), token cost (sum), and provenance (union of citations) over the *same* tree.
