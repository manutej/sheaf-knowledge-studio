# Operadic & Meta-Cognitive Catalog (L2 Reference)

**Skill:** `operadic-meta-suite` (`U_01`, `U_02` · `ch-1-meta-operadic`)  
**Absorbed Skills:** `meta-operad`, `op-consist`, `operadic-interview`, `meta-planning`, `meta-prompting`, `meta-mvp`, `split-work-rejoin`, `artifact-chain`, `noether-harness`, `category-master`

---

## 1. `meta-operad` & `op-consist` — Compositional Reliability & Operadic Consistency

### Theoretical Grounding
- **Primary Sources:** Bottman & Richardson (*Operadic Consistency for Multi-Agent & Prompt Trees*, `arXiv:2606.13634`, `arXiv:2606.13649`).
- **Core Problem:** A multi-step agent workflow modeled as a rooted tree $\mathcal{T}$ of operations often succeeds locally at every node $v \in V(\mathcal{T})$ while drifting globally from the intent of the collapsed root specification $\mathrm{collapse}(\mathcal{T})$.

### Formal Operadic Composition Law
Let $\mathcal{O}$ be a colored operad whose colors $C$ are typed artifact contracts (`Schema`, `Code`, `AuditReport`, `SheafKB`) and whose operations $\phi \in \mathcal{O}(c_1, \dots, c_k; c_0)$ are bounded agent tasks or deterministic scripts.
- **Associativity:** $\gamma(\gamma(\phi; \psi_1, \dots, \psi_k); \chi_{1,1}, \dots) = \gamma(\phi; \gamma(\psi_1; \chi_{1,*}), \dots)$.
- **Operadic Consistency Defect ($\Delta_{\mathrm{OC}}$):**
  $$\Delta_{\mathrm{OC}}(\mathcal{T}, x) = d\big(\mathrm{eval}(\mathcal{T})(x),\; \mathrm{eval}(\mathrm{collapse}(\mathcal{T}))(x)\big)$$
  where $d(\cdot, \cdot)$ measures structural/invariant divergence against the root contract.

### Three-Tier Operadic Consistency Protocol
1. **Tier 1 (End-to-End Collapse Probe):** Execute the decomposed workflow $\mathcal{T}$ on a canonical probe input $x_0$ and compare its invariant signature against single-shot execution of the root specification $\mathrm{collapse}(\mathcal{T})$.
2. **Tier 2 (Subtree Bisection):** When $\Delta_{\mathrm{OC}}(\mathcal{T}) > \tau$, contract internal edges $e \in E(\mathcal{T})$ binary-search style to isolate the **minimal inconsistency kernel** $\mathcal{K} \subseteq \mathcal{T}$ where local outputs fail to glue.
3. **Tier 3 (Edge Guard Installation):** Install deterministic validation probes exclusively on the three failure-bearing edge families:
   - **WITNESS Edges:** Does the child task's output provide a verifiable witness (file path, line number, test output) for the parent claim?
   - **INTERFACE Edges:** Does the JSON/CLI output of node $u$ strictly satisfy the input JSON Schema of downstream node $v$?
   - **VERIFICATION Edges:** Does the final artifact pass a negative-selftest linter (`corpus_contract_linter.py --selftest`)?

---

## 2. `operadic-interview` — N-Level Typed Question Trees (`/grill-me`)

When requirements are underspecified, avoid flat laundry lists of questions. Construct a **Typed Operadic Question Tree** $\mathcal{Q}$:
1. **Level 0 (Root Color Selection):** Ask 1–3 high-leverage architectural questions that partition the design space into mutually exclusive branches (e.g., *Static Monolith vs. Deferred Bundle + SQLite FTS5*, *Single-Turn CLI vs. Persistent MCP Server*).
2. **Level 1 (Fiber Refinement):** Generate follow-up questions **strictly conditioned** on the selected Level-0 branch color. Prune all irrelevant subtrees immediately.
3. **Termination Condition:** Stop interviewing as soon as the **Output Contract** $c_0$ and **Boundary Constraints** $(c_1, \dots, c_k)$ have zero ungrounded free variables. Compile answers directly into a locked `SPEC.md` or `TYPED-CONTRACT-*.md`.

---

## 3. `meta-planning` — Typed Work-Unit DAGs & Pre-Registered Checkpoints

Every complex build or refactor must be decomposed into a topologically sorted DAG of typed work units before mutating production files:

```text
WorkUnit[id] : (InputFiles, Preconditions) ──[Action / Script]──> (OutputFiles, PostconditionGate)
```

### Mandatory Work-Unit Fields
- **`unit_id`:** Stable identifier (`WU-01`, `WU-02`, ...).
- **`inputs`:** Explicit file paths and schema versions consumed.
- **`outputs`:** Explicit target files created or mutated.
- **`verification_cmd`:** Deterministic shell command that exits `0` iff the work unit succeeded.
- **`rollback_cmd`:** Antipode action that restores clean state if `verification_cmd` exits non-zero.

---

## 4. `meta-prompting` & `meta-mvp` — Functorial Scaffolds & Thin Vertical Slices

### Functorial Prompt Factorization (`meta-prompting`)
Separate any complex prompt or skill into:
1. **Syntax Category ($\mathcal{S}$):** Domain-agnostic structural skeleton (roles, phase gates, input/output slots, failure recovery rules).
2. **Semantics Functor ($F : \mathcal{S} \to \mathcal{D}$):** Binding table that maps abstract slots in $\mathcal{S}$ to concrete domain types in $\mathcal{D}$ (e.g., mapping `CorpusNode` $\mapsto$ `SkillMarkdownFile`, `RestrictionMap` $\mapsto$ `CrossSkillReference`).

### Minimum Viable Vertical Slice (`meta-mvp`)
- Never build horizontal layers in isolation (e.g., writing 10 schemas before testing 1 end-to-end compile).
- Always ship a **Thin Vertical Isomorphism** first: `1 Input Record -> 1 Compiler Pass -> 1 Rendered Output -> 1 Automated Gate Check`. Expand breadth only after the vertical slice passes `100%` of binary gates.

---

## 5. `split-work-rejoin` — Hopf Algebra Parallelization (`Δ, m, ε, S`)

When partitioning a large multi-file build across parallel subagents or batch workers, model the workflow as a **Hopf Algebra**:
1. **Coproduct ($\Delta : H \to H \otimes H$ — Split):**
   Partition the workspace into shards $W_1, \dots, W_k$ with **zero write-path collision** ($W_i^{\mathrm{write}} \cap W_j^{\mathrm{write}} = \emptyset$ for $i \neq j$) and an explicit **Boundary Overlap Contract** $B_{ij} = W_i^{\mathrm{read}} \cap W_j^{\mathrm{write}}$.
2. **Counit ($\varepsilon : H \to k$ — Local Gate):**
   Each shard $W_i$ must pass its local unit/schema check before requesting rejoin.
3. **Product ($m : H \otimes H \to H$ — Rejoin):**
   Merge shards only after verifying zero boundary restriction defect ($\|\delta^0 s\|_{B_{ij}} = 0$) across all shared interfaces, imports, and IDs.
4. **Antipode ($S : H \to H$ — Rollback):**
   Maintain a deterministic inverse patch or backup snapshot so any failed shard can be reverted without corrupting sibling shards.

---

## 6. `artifact-chain` & `noether-harness` — Micro-Step Synthesis & Conservation Laws

- **Micro-Step Granularity ($m = 1$):** For long-form code, courseware modules, or multi-plate HTML studios, generate or mutate one bounded section/plate at a time, running a fast syntax/invariant check after each step.
- **Noether Symmetry-to-Gate Law (`noether-harness`):** Every stated invariant in a specification ("no module numbers", "every stalk has `>= 1` page", "every MCP server exposes 3 canonical tools") must be paired with a deterministic conservation check in the audit script. An invariant without an automated gate decays under iteration.
