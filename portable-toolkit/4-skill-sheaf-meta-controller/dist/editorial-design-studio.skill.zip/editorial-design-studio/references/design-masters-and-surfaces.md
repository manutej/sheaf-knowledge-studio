# Editorial Design Studio — Masters, Semiology & Surfaces (L2 Reference)

**Skill:** `editorial-design-studio` (`U_07`, `U_08` · `ch-3-design-media`)  
**Absorbed Skills:** `sheaf-field-manual-studio`, `editorial-dashboard`, `client-briefing-dashboard`, `deck-studio`, `generative-ui`, `shadcn-concept-page`, `ui-audit`, `bertin`, `wada`, `milton`, `milton-2`, `sagmeister`, `saul`, `rem`

---

## 1. Surface Archetype Decision Matrix

Choose the target HTML/UI surface strictly from the data topology and audience task:

| Archetype | Primary Skill / Script | Canonical Palette & Typography | Mandatory Structural Plates |
|---|---|---|---|
| **CETI Field-Manual & Meta-Notebook** (`>= 20` pages or sheaf stalks) | `sheaf-field-manual-studio` (`compile_field_manual_studio.py`) | Warm Cream Paper `#F5EFE3`, Deep Ink `#1A1612`, Vermilion `#C83E2B`, Slate Teal `#1E5663`, Ochre `#C98A27`; `Fraunces` + `DM Sans` + `JetBrains Mono` | **5 Plates:** `I. Architecture`, `II. Notebook Gluing Studio` (Audio + Commutativity Matrix), `III. Symbolic Visual Sandbox`, `IV. Corpus Observed & 3D Poset`, `V. Course Blueprint` + Slide-Over Reader |
| **Push Pin Editorial Feature Dashboard** | `editorial-dashboard` + `milton` | Warm Newsprint `#F7F2E7`, Heavy Ink `#141210` (`2.5px` borders), Glaser 5-Actor Semantic Colors | Masthead + Hero Spot Illustration + Interactive Chart.js / SVG Data Grid + Marginalia Callouts |
| **Executive / Client Institutional Briefing** | `client-briefing-dashboard` | Deep Navy `#0F172A`, Warm Ivory `#FAF8F5`, Amber Signal `#D97706` | Decision Summary Ribbon + KPI Delta Cards + Scenario Comparison Matrix + Risk Ledger |
| **Keynote / Adversarial Audit Deck** | `deck-studio` | High-contrast 16:9 stage plates, zero bullet walls (`<= 35 words/slide`) | Title Manifesto + Architecture Diagram + Empirical Scorecard + Action Roadmap |
| **Interactive App / Concept Prototype** | `generative-ui` / `shadcn-concept-page` | Semantic CSS variables (`--bg`, `--surface`, `--ink`, `--accent`), responsive CSS Grid | Live Interactive Controls + State Inspector + Self-Contained Zero-Build HTML/JS |

---

## 2. Jacques Bertin's Graphic Semiology (`bertin`)

Every chart, diagram, and topological canvas must obey Bertin's hierarchy of retinal variables (*Sémiologie Graphique*, 1967):

1. **Planar Position ($X, Y$):** Reserved for the two highest-entropy variables (e.g., *Domain Chapter* on $X$ vs. *Abstraction Tier / Cohomology Defect* on $Y$, or 3D spring-embedded poset projection).
2. **Size / Length / Area:** Strictly for **quantitative ratios** (token counts, page fiber spans, duration). Never map nominal categories to size.
3. **Value (Lightness / Ink Density):** Strictly for **ordered / monotonic metrics** (restriction fidelity $f_{ij} \in [0.5, 1.0]$, severity `P0 > P1 > P2`).
4. **Hue (Color):** For **selective nominal grouping** ($\le 7$ distinct categories so pre-attentive visual search remains $O(1)$).
5. **Shape / Orientation / Texture:** Secondary redundant encoding paired with Hue to guarantee **Non-Color-Alone Accessibility (`HF-STUDIO-06`)**:
   - `◆ H⁰ Exact Gluing` (Teal `#1E5663`)
   - `⚖ Bounded Tension` (Ochre `#C98A27`)
   - `⊘ H¹ Obstruction / P0 Blocker` (Vermilion `#C83E2B`)

---

## 3. Sanzo Wada Chromatic Combinations (`wada`)

Avoid oversaturated default RGB primaries (`#FF0000`, `#00FF00`, `#0000FF`) and generic AI purple-to-cyan gradients. Use pigment-grounded harmonies from Sanzo Wada's *Haishoku Soukan* (1933):

| Palette Name | Background / Paper | Primary Ink | Accent 1 (Signal) | Accent 2 (Structure) | Accent 3 (Highlight) |
|---|---|---|---|---|---|
| **Archive Monograph (Default Studio)** | `#F5EFE3` (Raw Parchment) | `#1A1612` (Sumi Ink) | `#C83E2B` (Cinnabar Vermilion) | `#1E5663` (Prussian Teal) | `#C98A27` (Raw Ochre) |
| **Push Pin Lithograph (`milton`)** | `#FBF6EC` (Warm Rag) | `#181512` (India Ink) | `#D94E34` (Cadmium Scarlet) | `#2B5B84` (Cobalt Blue) | `#E09F3E` (Naples Yellow) |
| **Nocturnal Oscilloscope (`ceti-explainer`)** | `#12131A` (Carbon Slate) | `#F3EFE6` (Chalk Ivory) | `#FF6B4A` (Signal Coral) | `#38BDF8` (Cathode Cyan) | `#FBBF24` (Amber Trace) |

---

## 4. The 4 Master Visual Languages (On-Demand Lenses)

When the user requests a distinctive creative direction, apply one of the four master lenses:
1. **Milton Glaser (`milton` / `milton-2`):**
   - **8-Phase Process:** Affection $\to$ Question $\to$ Ten Variants $\to$ Pun Pass $\to$ Critique $\to$ Refine $\to$ Strip $\to$ Truth Check.
   - **Visual Signature:** Hand-inked round stroke caps (`stroke-linecap="round"`), negative-space paper cutouts (`fill="var(--paper)"`), 2.5D lithographic shadow offsets, and conceptual visual metaphors.
2. **Stefan Sagmeister (`sagmeister`):**
   - **Visual Signature:** Radical empirical candor, structural vulnerability (exposing the actual failed gates and exact defects alongside the triumph), bespoke typographic callouts.
3. **Saul Bass (`saul`):**
   - **Visual Signature:** Cut-paper geometric shards, stark silhouette reduction, kinetic diagonal tension, vermilion/ochre/carbon-black triad.
4. **Rem Koolhaas / AMO (`rem`):**
   - **Visual Signature:** Statistical maximalism, dense comparative barcode/timeline strips, retroactive manifesto headings, axonometric programmatic cutaways.

---

## 5. Field-Manual Studio & UI Verification Gates (`HF-STUDIO-01` .. `HF-STUDIO-11`)

Before delivering any HTML studio or dashboard, run `.agents/skills/sheaf-field-manual-studio/scripts/verify_studio_gates.py`:
- **`HF-STUDIO-01` (Deferred Bundle):** Initial HTML stays fast (`< 500 KB`) by loading full page text from `sheaf_pages_bundle.js`.
- **`HF-STUDIO-02` (5 Plates):** All 5 structural plates render with interactive tab switching.
- **`HF-STUDIO-03` (Zero Raw LaTeX):** Zero unrendered `\mathcal`, `\check`, `\xrightarrow`, or `\simeq` strings in visible DOM text.
- **`HF-STUDIO-09` (Zero Template Bleed):** Corpus-adapted studios must contain zero leftover strings from unrelated books (e.g., no `SPIVAK` or `Category Theory Illustrated` in a non-Spivak studio).
- **`HF-STUDIO-10` & `HF-STUDIO-11` (Dynamic Blueprint & Custom Podcast Turns):** Plate V dynamically renders `KB.book.course_modules`, the Slide-Over Reader uses dynamic `maxCorpusPages`, and Plate II renders `inv.podcast_turns` when present.


---

## 6. Canonical CSS Token Contract & Mathematical Symbol Typesetting Table

Every editorial dashboard and field-manual studio must define a root `:root` semantic token block and normalize raw LaTeX strings into proper Unicode or MathML before DOM injection:

```css
:root {
  --paper: #F5EFE3;
  --paper-elevated: #FBF7EE;
  --ink: #1A1612;
  --ink-muted: #5C5346;
  --rule: rgba(26, 22, 18, 0.16);
  --vermilion: #C83E2B;
  --teal: #1E5663;
  --ochre: #C98A27;
  --font-serif: 'Fraunces', Georgia, serif;
  --font-sans: 'DM Sans', -apple-system, sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}
```

### Zero-Leakage Symbol Mapping (`formatMathSymbols()`)
| Raw LaTeX Token | Rendered Typographic Output | Semantic Usage |
|---|---|---|
| `\mathcal{F}(U_i)` | `ℱ(Uᵢ)` | Stalk section over open set $U_i$ |
| `\check{H}^1(\mathcal{U}, \mathcal{F})` | `Ȟ¹(𝒰, ℱ)` | First Čech cohomology obstruction group |
| `\|\delta^0 s\|_{ij}` | `‖δ⁰s‖ᵢⱼ` | Pairwise 0-cochain restriction defect |
| `\|\delta^1 \omega\|_{ijk}` | `‖δ¹ω‖ᵢⱼₖ` | 2-simplex triangle holonomy defect |
| `\rho_{U,V}` | `ρ_{U,V}` | Restriction morphism from $U$ to $V$ |
