---
name: editorial-design-studio
description: Master router for Editorial Dashboards, CETI Field-Manual Volumes, Bertin Graphic Semiology, Wada Color Palettes, Master Visual Languages, and React/Shadcn UI Surfaces.
---

# Editorial Design Studio (`editorial-design-studio`)

Consolidates **25 Design, Editorial, Color & UI skills** (`stalk-07-field-manual-editorial-volumes`, `stalk-08-graphic-semiology-masters`, `stalk-09-interactive-web-ui-systems`) into a single parameterized Master Studio eliminating trigger collisions across `dashboard` / `HTML artifact` prompts.

---

## 1. Two-Axis Parameterization (`Surface × Master Lens`)

Every visual deliverable is specified by choosing **1 Surface Archetype** and **1 Chromatic / Semiotic Lens**:

### Axis A — Surface Archetypes (`L2` Routers)
1. **CETI Field-Manual & Meta-Notebook (`sheaf-field-manual-studio`, `field-notebook-craft`, `field-story`):** Warm Cream Paper (`#F5EFE3`), Deep Ink (`#1A1612`), Browning Copper (`#A67756`), `Fraunces`/`DM Sans`/`JetBrains Mono`, 5 Editorial Plates, `.marginalia`, `.counterpoint`, non-color-alone stamps (`◆`, `⚖`, `✓`, `±`, `⊘`), `< 450 KB` split bundle, zero raw LaTeX leakage.
2. **Push-Pin / Institutional Executive Dashboard (`editorial-dashboard`, `client-briefing-dashboard`, `docs-dashboard`, `go-there`):** Tactile ink-outlined SVG spot illustrations paired with interactive Chart.js/SVG data views.
3. **Keyboard-Driven Slide Studio (`deck-studio`, `motion-stack`):** Single-file HTML slide deck + live auditor/presenter.
4. **Interactive Web & React/Shadcn Concept Surface (`generative-ui`, `shadcn-concept-page`, `frontend-design`, `ui-audit`):** Stateful React/TypeScript or vanilla interactive widgets with tell-apart visual hierarchy audits.

### Axis B — Master Visual & Semiotic Lenses (`L2` References)
- **Jacques Bertin (`bertin`):** Retinal variable hierarchy (Planar $X,Y > \text{Size} > \text{Value} > \text{Texture} > \text{Hue} > \text{Orientation} > \text{Shape}$). Correct before pretty.
- **Sanzo Wada (`dict-color`):** Historical 2-, 3-, and 4-color combinations from *A Dictionary of Color Combinations*.
- **Editorial Masters (`milton-2` Glaser, `sagmeister`, `saul` Bass, `rem` Koolhaas):** Load only when explicitly requested via `references/design-masters-and-surfaces.md`.

---

## 2. Progressive-Disclosure L2 & L3 Routing Table

| Sub-Task / Trigger | L2 Reference / Skill Path | L3 Verification Script |
|---|---|---|
| **5-Plate Sheaf Field-Manual HTML** | `.agents/skills/sheaf-field-manual-studio/SKILL.md` | `.agents/skills/sheaf-field-manual-studio/scripts/audit_rendered_html.py` |
| **Push-Pin Editorial HTML Dashboard** | `.agents/skills/editorial-dashboard/SKILL.md` | `references/design-masters-and-surfaces.md` (§1) |
| **Bertin Semiology & Wada Palettes** | `references/design-masters-and-surfaces.md` (§2) | `~/.grok/skills/bertin/SKILL.md` · `~/.grok/skills/dict-color/SKILL.md` |
| **Glaser / Sagmeister / Bass / Rem** | `references/design-masters-and-surfaces.md` (§3) | `~/.grok/skills/meta-design/SKILL.md` |
| **Interactive Widget / React Shadcn** | `references/design-masters-and-surfaces.md` (§4) | `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/shadcn-concept-page/SKILL.md` |
