---
name: sheaf-research-memory
description: Master router for Sheaf Knowledge Bases, Harmonic Graph Memory, Noether Wikis, Continuous Research Loops, and the Skill-Sheaf Meta-Controller.
---

# Sheaf Research & Graph Memory (`sheaf-research-memory`)

Unifies **11 Research, Indexing & Graph Memory skills** (`stalk-03-alexandrov-sheaf-indexing`, `stalk-04-harmonic-graph-memory`, `stalk-05-continuous-research-loop`) into a single **Alexandrov Sheaf + Harmonic Laplacian Memory Architecture** governing both domain corpora and the **81-skill meta-graph itself**.

---

## 1. The Unified Sheaf Research Loop (`WATCH → INDUCE → COHOMOLOGY GATE → STAGE → COMMIT → SERVE`)

1. **WATCH & INGEST (`Δ_WATCH`, `Π_INGEST`):** Track PDFs, arXiv papers, YouTube transcripts, web watches, or skill directories under a declared query budget (`B_BUDGET`).
2. **SHEAF INDUCTION (`Λ_SHEAF`):** Instead of flat RAG chunks or isolated atoms, extract page/file-anchored **Concept Stalks ($U_i$)**, local **Ologs (`types`, `aspects`, `facts`)**, and **Restriction Morphisms ($\rho_{U,V}$)** using `portable-toolkit/1-page-anchored-indexer/page_corpus_indexer.py`.
3. **COHOMOLOGY & MOE GATE (`Γ_GATE`):** Verify 12 binary sheaf invariants (`HF-SHEAF-01..12`), empirical restriction fidelity $f_{ij} = 1 - \|\delta^0 s\|_{ij}$, 2-simplex holonomy $\|\delta^1 \omega\|_{ijk} \le 0.35$, and $\check{H}^1$ polysemy obstructions via `corpus_contract_linter.py`.
4. **HARMONIC STAGING (`HierSheafMemory.stage_delta`):** Preview new knowledge deltas against frozen boundary embeddings (`absorption_residual`, `existing_pair_tension`) before committing to `wiki/`.
5. **SERVE & ROUTE (`SQLite FTS5` + `--mcp`):** Serve cited answers and progressive-disclosure skill routes via `query_corpus.py` / `query_skill_sheaf.py --mcp`.

---

## 2. Progressive-Disclosure L2 & L3 Routing Table

| Sub-Task / Trigger | L2 Reference / Skill | L3 Executable Script |
|---|---|---|
| **Route Skills & Audit Token Budget** | `references/sheaf-loop-and-harmonic-memory.md` (§1) | `portable-toolkit/4-skill-sheaf-meta-controller/query_skill_sheaf.py` |
| **Rebuild 81-Skill Sheaf Graph Memory** | `references/sheaf-loop-and-harmonic-memory.md` (§1) | `portable-toolkit/4-skill-sheaf-meta-controller/skill_sheaf_compiler.py` |
| **Index Any PDF/Book into Sheaf KB** | `.agents/skills/sheaf-corpus-indexer/SKILL.md` | `portable-toolkit/1-page-anchored-indexer/page_corpus_indexer.py` |
| **Lint Sheaf Contract & Cohomology** | `.agents/skills/sheaf-knowledge-pipeline/SKILL.md` | `portable-toolkit/2-json-contract-linter/corpus_contract_linter.py` |
| **Log Round Scorecard (`META-LEARNING-LOG`)** | `references/sheaf-loop-and-harmonic-memory.md` (§2) | `portable-toolkit/3-gate-review-runner/gate_review_runner.py` |
| **Harmonic Sheaf Memory (`stage_delta`)** | `references/sheaf-loop-and-harmonic-memory.md` (§3) | `~/.claude/skills/synced/ef36a148-c3ad-432f-8379-66f6ce82c4f3_2955edd5-b0fb-4198-84b4-db3d4bc035fd/sheaf-memory/scripts/hierarchical_sheaf_memory.py` |
| **Persistent Noether Wiki & `/loop`** | `references/sheaf-loop-and-harmonic-memory.md` (§4) | `~/.grok/skills/noether-wiki/SKILL.md` |
