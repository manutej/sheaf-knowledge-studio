# Sheaf Research Loop & Harmonic Graph Memory Specification (L2 Reference)

**Skill:** `sheaf-research-memory` (`U_04`, `U_05`, `U_06` · `ch-2-sheaf-knowledge`)  
**Absorbed Skills:** `sheaf-knowledge-pipeline`, `sheaf-corpus-indexer`, `sheaf-memory`, `noether-wiki`, `loop`, `meta-research`, `courseware-research-swarm`, `meta-notebook`

---

## 1. Alexandrov Topology & Sheaf Knowledge Base Architecture

Given a corpus $X$ (either a long-form PDF monograph of $100\text{--}1,000+$ pages or an ecosystem of $N$ agent skills), we equip $X$ with an **Alexandrov Poset Topology** $(P, \le)$ covered by open sets $\mathcal{U} = \{U_1, \dots, U_m\}$ (concept stalks):

1. **Base Space ($X$) & Fiber Map ($p : E \to X$):**
   Every page or skill file $x \in X$ is indexed in SQLite FTS5 (`cattheory_sheaf.db`) and `sheaf_pages_bundle.js` with full verbatim text, extracted declarations, and token/line metrics.
2. **Stalks ($\mathcal{F}(U_i)$):**
   Each open set $U_i$ carries a structured section tuple:
   $$\mathcal{F}(U_i) = \big(\text{Summary},\; \text{Formal Law},\; \text{Declarations},\; \text{Page Fibers},\; \text{Token/Skill Metadata}\big)$$
3. **Restriction Morphisms ($\rho_{U_i, U_j} : \mathcal{F}(U_i) \to \mathcal{F}(U_i \cap U_j)$):**
   Directed edges between overlapping stalks storing shared vocabulary, shared symbolic operators, cross-citations, and empirical gluing fidelity $f_{ij} \in [0, 1]$.

---

## 2. Empirical Čech Cohomology & Obstruction Auditing (`sheaf_induction_engine.py`)

Never fabricate or hardcode cohomology numbers. Every `sheaf_kb.json` must compute empirical Čech invariants from corpus text:

### 0-Cochain Restriction Defect ($\|\delta^0 s\|_{ij}$)
For every directed overlap $e_{ij} = (U_i \to U_j)$, compute the 5-signal restriction fidelity:
$$f_{ij} = \mathrm{clip}_{[0.52, 0.99]}\!\Big(0.32\,\mathrm{cos}_{\mathrm{TFIDF}}(U_i, U_j) + 0.28\big(1 - D_{\mathrm{JS}}(P_i \| P_j)\big) + 0.16\,\mathrm{Jaccard}_{\mathrm{terms}} + 0.14\,\mathrm{Cite}_{i \to j} + 0.10\,\mathrm{Proximity}_{ij}\Big)$$
The pairwise 0-coboundary defect is $\|\delta^0 s\|_{ij} = 1 - f_{ij}$.

### 1-Cocycle Holonomy Defect ($\|\delta^1 \omega\|_{ijk}$)
On every 2-simplex triangle $[U_i, U_j, U_k]$ in the nerve $\mathcal{N}(\mathcal{U})$ where edges $(i,j)$, $(j,k)$, and $(i,k)$ exist:
$$\|\delta^1 \omega\|_{ijk} = \big|\,\|\delta^0 s\|_{ij} + \|\delta^0 s\|_{jk} - \|\delta^0 s\|_{ik}\,\big|$$
- **Exact Gluing (`HF-SHEAF-06`):** Requires max pairwise defect $\le 0.35$ and mean fidelity $\ge 0.80$.

### Global Topological Diagnostics ($\beta_0, \beta_1, \chi, \check{H}^1$)
- **Connected Components ($\beta_0$):** Computed via BFS on the undirected nerve. If $\beta_0 > 1$, emit an explicit $\check{H}^1$ topological disconnection obstruction (`HF-SHEAF-05`).
- **Euler Characteristic ($\chi$):** $\chi(\mathcal{N}(\mathcal{U})) = |V| - |E| + |T|$, with cyclomatic loop rank $\beta_1 = |E| - |V| + \beta_0$.
- **Notebook Investigations (`notebook_investigations[*]`):** Every investigation must include `cohomology.h0_dimension`, `cohomology.h1_obstruction`, `cohomology.holonomy_defect`, `cohomology.status`, and `podcast_turns` (`>= 4` turns).

---

## 3. Skill-Sheaf Meta-Controller (`portable-toolkit/4-skill-sheaf-meta-controller/`)

The Skill-Sheaf Meta-Controller applies the Alexandrov Sheaf engine directly to the workspace's skill directories:

```bash
# 1. Re-compile the Skill Sheaf KB, SQLite FTS5 DB, and Persistent Wiki
python3 portable-toolkit/4-skill-sheaf-meta-controller/skill_sheaf_compiler.py --out skill-sheaf-kb

# 2. Route any task prompt using 4-tier progressive disclosure (L0 -> L1 -> L2 -> L3)
python3 portable-toolkit/4-skill-sheaf-meta-controller/query_skill_sheaf.py \
  --route "build an interactive Argon explainer with sheaf cohomology audit"

# 3. Audit open-cover health, Betti numbers, and restriction fidelity
python3 portable-toolkit/4-skill-sheaf-meta-controller/query_skill_sheaf.py --audit-cover

# 4. Run as a JSON-RPC 2.0 MCP Server (exposes both canonical sheaf_* and skill_sheaf_* tools)
python3 portable-toolkit/4-skill-sheaf-meta-controller/query_skill_sheaf.py --mcp
```

---

## 4. Harmonic Extension Staging (`sheaf-memory`)

When maintaining an evolving entity-relation knowledge graph $\mathcal{G} = (V, E, R)$ in $\mathbb{R}^d$:
1. **Translational Sheaf Potential:** Each relation triple $(h, r, t)$ induces a local consistency energy $\mathcal{E}(h, r, t) = \|x_h + \mathbf{r} - x_t\|_2^2$.
2. **Kron Reduction / Harmonic Staging (`stage_delta`):**
   Before committing newly extracted research claims $E_{\mathrm{new}}$ to persistent memory:
   - Fix existing verified anchor nodes $V_{\mathrm{anchor}}$ as Dirichlet boundary conditions,
   - Solve the graph Laplacian boundary-value problem $L_{\mathrm{int}}\, x_{\mathrm{new}} = -L_{\mathrm{bd}}\, x_{\mathrm{anchor}} + b_{\mathrm{rel}}$ for new entities,
   - Compute **`absorption_residual`** (how well new facts fit existing laws) and **`existing_pair_tension`** (whether new facts distort verified anchor distances).
3. **Quarantine Rule:** Any triple whose `existing_pair_tension` exceeds threshold $\tau_{\mathrm{tension}}$ is quarantined as an explicit $\check{H}^1$ contradiction for adversarial verification rather than silently overwriting prior memory.

---

## 5. Continuous Research Loop (`/loop` + `noether-wiki`)

Every autonomous or scheduled research cycle executes a 6-verb state machine logged append-only to `ledger.jsonl`:

| Verb | Action | Required Disk Output |
|---|---|---|
| `WATCHED` | Poll frontier sources, papers, or repository diffs | Source URL / SHA-256 hash recorded |
| `INGESTED` | Extract verbatim claims, equations, or pages into fibers | `sheaf_kb.json` / `cattheory_sheaf.db` updated |
| `DISTILLED` | Synthesize local stalk section & restriction morphisms | `wiki/concepts/<stalk>.md` updated |
| `GATED` | Run `run_sheaf_pipeline_audit.py` + harmonic tension check | `adversarial-eval/rN_moe_audit.json` |
| `MINTED` | Promote verified global section into permanent wiki/skill | `wiki/HOME.md` & `wiki/LEDGER.md` row appended |
| `ASKED` | Emit next high-entropy open research question | Queued for next `/loop` iteration |
